import { useState, useMemo } from 'react';
import Hero from '../components/home/Hero';
import FilterSidebar from '../components/home/FilterSidebar';
import PropertyCard from '../components/home/PropertyCard';
import PropertyDetailsModal from '../components/home/PropertyDetailsModal';
import { MOCK_PROPERTIES } from '../data/mockData';
import { FilterState, Property } from '../types';
import { AnimatePresence, motion } from 'motion/react';
import { useToast } from '../components/ui/ToastProvider';
import { Search } from 'lucide-react';

export default function HomePage() {
  const [filters, setFilters] = useState<FilterState>({
    priceRange: [0, 2000],
    types: [],
    rating: 0,
    amenities: [],
  });

  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const { showToast } = useToast();

  const filteredProperties = useMemo(() => {
    return MOCK_PROPERTIES.filter(property => {
      // Filter by Price
      if (property.price < filters.priceRange[0] || property.price > filters.priceRange[1]) {
        return false;
      }
      
      // Filter by Type (if any selected)
      if (filters.types.length > 0 && !filters.types.includes(property.type)) {
        return false;
      }

      // Filter by Rating (if selected)
      if (filters.rating > 0 && Math.floor(property.rating) < filters.rating) {
        return false;
      }

      // Filter by Amenities (must have ALL selected amenities)
      if (filters.amenities.length > 0) {
        const hasAllAmenities = filters.amenities.every(a => 
          property.amenities.includes(a) || (a === 'Pool' && property.amenities.some(p => p.includes('Pool')))
        );
        if (!hasAllAmenities) return false;
      }

      return true;
    });
  }, [filters]);

  return (
    <div className="w-full">
      <Hero />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col lg:flex-row gap-10">
          <aside className="w-full lg:sticky lg:top-28 lg:self-start lg:w-64">
            <FilterSidebar 
              filters={filters} 
              setFilters={setFilters} 
              totalResults={filteredProperties.length}
            />
          </aside>
          
          <main className="flex-1 flex flex-col gap-6 w-full overflow-hidden">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-2">
              <h2 className="text-3xl font-serif font-bold text-brand-dark">
                The Global Collection
                <span className="text-base font-sans not-italic font-bold text-brand-dark ml-3">({filteredProperties.length} properties)</span>
              </h2>
              <div className="flex gap-4 text-[10px] font-bold uppercase tracking-widest text-brand-dark items-center">
                <span className="text-brand-dark">Sort by:</span>
                <button className="border-b-[2px] border-brand-primary text-brand-primary active:scale-95 transition-transform py-1">Featured</button>
                <button className="text-brand-dark hover:text-brand-primary transition-all active:scale-95 py-1">Price</button>
                <button className="text-brand-dark hover:text-brand-primary transition-all active:scale-95 py-1">Rating</button>
              </div>
            </div>

            <motion.div layout className="grid grid-cols-1 md:grid-cols-2 gap-6 relative min-h-[400px]">
              <AnimatePresence mode="popLayout">
                {filteredProperties.length > 0 ? (
                  filteredProperties.map((property, index) => (
                    <motion.div
                      key={property.id}
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.3 }}
                    >
                      <PropertyCard 
                        property={property} 
                        index={index} 
                        onViewDetails={setSelectedProperty} 
                      />
                    </motion.div>
                  ))
                ) : (
                  <motion.div 
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className="col-span-full py-20 flex flex-col items-center justify-center text-center bg-brand-cream/30 rounded-[2rem] border border-brand-secondary/20"
                  >
                    <Search className="w-16 h-16 text-brand-primary/40 mb-6" />
                    <p className="text-3xl font-serif font-bold text-brand-dark mb-4">No sanctuaries match your search</p>
                    <p className="text-brand-dark font-sans font-bold max-w-md mb-8">We couldn't find any properties matching your current filters. Try adjusting your search criteria to discover hidden gems.</p>
                    <button 
                      onClick={() => setFilters({ priceRange: [0, 2000], types: [], rating: 0, amenities: [] })}
                      className="px-8 py-3 bg-brand-dark text-brand-ivory text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-brand-primary transition-all active:scale-95 shadow-md flex items-center justify-center gap-2"
                    >
                      Clear Filters
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Partner Portal Micro Feature */}
            {filteredProperties.length > 0 && (
              <div className="mt-8 p-4 border border-dashed border-brand-secondary rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 transition-colors hover:bg-brand-cream/50">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-brand-dark flex items-center justify-center text-white font-serif italic text-lg shadow-sm">M</div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-brand-dark">List your luxury property</p>
                    <p className="text-[10px] font-bold uppercase text-brand-dark mt-0.5">Join our exclusive collection of premium hosts</p>
                  </div>
                </div>
                <button 
                  onClick={() => showToast({ title: 'Navigating to Partner Onboarding... (Mockup)', type: 'info' })}
                  className="text-xs font-bold underline px-4 text-brand-dark hover:text-brand-primary transition-colors active:scale-95"
                >
                  Partner Onboarding
                </button>
              </div>
            )}

            {filteredProperties.length > 0 && (
              <div className="mt-8 flex justify-center">
                <button 
                  onClick={() => showToast({ title: 'Loading more properties... (Mockup)', type: 'info' })}
                  className="px-10 py-4 bg-brand-primary text-brand-ivory font-bold text-xs tracking-widest uppercase rounded-xl hover:bg-brand-dark transition-all duration-300 active:scale-95 shadow-md"
                >
                  Load More Properties
                </button>
              </div>
            )}
          </main>
        </div>
      </div>
      
      {/* About Us Section */}
      <section className="bg-brand-dark py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-serif font-bold text-brand-ivory mb-4">About Madyaw</h2>
          <p className="text-brand-cream/80 font-sans font-medium leading-relaxed text-sm mb-6">
            <strong className="text-brand-primary">Madyaw</strong> represents the ultimate curated collection of hidden gems and globally recognized luxury sanctuaries. We believe travel should be seamless, elegant, and deeply authentic. Our name is rooted in hospitality, and our mission is to offer you an unwavering standard of excellence.
          </p>
          <div className="flex flex-wrap justify-center gap-6 md:gap-10 text-brand-ivory font-sans">
            <div className="flex flex-col items-center">
              <span className="text-2xl font-serif font-bold text-brand-primary mb-1">500+</span>
              <span className="text-[9px] uppercase tracking-widest font-bold text-brand-cream/60">Curated Villas</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-2xl font-serif font-bold text-brand-primary mb-1">24/7</span>
              <span className="text-[9px] uppercase tracking-widest font-bold text-brand-cream/60">Concierge</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-2xl font-serif font-bold text-brand-primary mb-1">100%</span>
              <span className="text-[9px] uppercase tracking-widest font-bold text-brand-cream/60">Verified Stays</span>
            </div>
          </div>
        </div>
      </section>

      {/* Property Details Modal */}
      {selectedProperty && (
        <PropertyDetailsModal 
          property={selectedProperty} 
          onClose={() => setSelectedProperty(null)} 
        />
      )}
    </div>
  );
}

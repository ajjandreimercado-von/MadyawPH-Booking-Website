import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_PROPERTIES } from '../data/mockData';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useToast } from '../components/ui/ToastProvider';

export default function TransactionPage() {
  const { propertyId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast } = useToast();
  
  const [isConfirming, setIsConfirming] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const property = MOCK_PROPERTIES.find(p => p.id === propertyId);

  useEffect(() => {
    // If not signed in and trying to access this page directly, ideally we redirect to home
    // But since the requirement might assume we only hit this through the flow, it is fine.
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  if (!property) {
    return <div className="pt-32 text-center">Property not found</div>;
  }

  const handleConfirm = () => {
    setIsConfirming(true);
    setTimeout(() => {
      setIsConfirming(false);
      setIsSuccess(true);
      showToast({ title: 'Booking Confirmed!', description: `Your luxurious stay at ${property.name} awaits.`, type: 'success' });
      setTimeout(() => {
        navigate('/');
      }, 3000);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen pt-32 bg-brand-cream/30 flex items-center justify-center p-4">
        <div className="bg-white p-12 rounded-[2rem] shadow-luxury max-w-md w-full text-center border border-brand-primary/10">
          <div className="w-20 h-20 bg-brand-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-brand-primary" />
          </div>
          <h2 className="text-3xl font-serif font-bold text-brand-dark mb-4">Confirmed</h2>
          <p className="text-brand-dark font-sans font-bold mb-8">
            Your booking for <strong className="text-brand-primary">{property.name}</strong> is all set. We've sent the details to {user?.email}.
          </p>
          <button 
            onClick={() => navigate('/')}
            className="px-8 py-3 bg-brand-primary text-brand-ivory text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-brand-dark transition-all active:scale-95 shadow-md w-full"
          >
            Return to Collection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 bg-brand-cream/30 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-brand-dark/60 hover:text-brand-primary font-bold text-xs uppercase tracking-widest mb-8 transition-colors active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Go Back</span>
        </button>

        <div className="bg-white rounded-[2rem] p-8 md:p-12 shadow-luxury border border-brand-primary/10">
          <h1 className="text-4xl font-serif font-bold text-brand-dark mb-8 border-b border-brand-secondary/20 pb-6">Checkout</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-brand-dark drop-shadow-sm mb-4">Guest Details</h3>
              <div className="bg-brand-ivory/50 rounded-2xl p-6 border border-brand-secondary/20 mb-8">
                <p className="text-sm font-bold text-brand-dark mb-1">{user?.name}</p>
                <p className="text-sm font-bold text-brand-dark">{user?.email}</p>
              </div>

              <h3 className="text-[10px] font-bold uppercase tracking-widest text-brand-dark drop-shadow-sm mb-4">Payment Method</h3>
              <div className="bg-brand-ivory/50 rounded-2xl p-6 border border-brand-secondary/20 border-l-4 border-l-brand-primary">
                <p className="text-sm font-bold text-brand-dark mb-1">•••• •••• •••• 4242</p>
                <p className="text-sm font-bold text-brand-dark">Exp: 12/26</p>
              </div>
            </div>

            <div className="bg-brand-cream rounded-3xl p-8 border border-brand-secondary/20 shadow-sm">
              <h3 className="text-xl font-serif font-bold text-brand-dark mb-6">Booking Summary</h3>
              
              <div className="flex gap-4 mb-6">
                <img src={property.images[0]} alt={property.name} className="w-24 h-24 object-cover rounded-xl shadow-sm" />
                <div>
                  <p className="text-lg font-serif font-bold text-brand-dark leading-tight mb-1">{property.name}</p>
                  <p className="text-sm font-bold text-brand-dark">{property.location}</p>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-sm font-bold text-brand-dark">
                  <span>1 Night</span>
                  <span className="font-bold">${property.price}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-brand-dark">
                  <span>Taxes & Fees</span>
                  <span className="font-bold">${Math.round(property.price * 0.15)}</span>
                </div>
              </div>

              <div className="border-t border-brand-secondary/40 pt-6 mb-8 flex justify-between items-end">
                <span className="text-sm font-bold uppercase tracking-widest text-brand-dark">Total</span>
                <span className="text-3xl font-serif font-bold text-brand-primary">${Math.round(property.price * 1.15)}</span>
              </div>

              <button 
                onClick={handleConfirm}
                disabled={isConfirming}
                className="w-full px-8 py-4 bg-brand-primary text-brand-ivory text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-brand-dark transition-all active:scale-95 shadow-md disabled:opacity-70 flex justify-center items-center"
              >
                {isConfirming ? (
                  <div className="w-5 h-5 border-2 border-brand-ivory/30 border-t-brand-ivory rounded-full animate-spin" />
                ) : (
                  'Confirm Booking'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

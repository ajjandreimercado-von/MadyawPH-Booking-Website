import { Property } from '../../types';

export const MOCK_PROPERTIES: Property[] = [
  {
    id: 1,
    name: "Villa Smeralda Resort",
    location: "Positano, Italy",
    distance: "2km from center",
    rating: 4.9,
    reviews: 320,
    price: 1280,
    image: "https://images.unsplash.com/photo-1519449556851-5720b33024e7?auto=format&fit=crop&q=80&w=800",
    amenities: ["Private Pool", "Spa", "Ocean View", "Free Breakfast", "Private Beach"],
    type: "Resort"
  },
  {
    id: 2,
    name: "Hotel Miramare Excelsior",
    location: "Amalfi Center, Italy",
    distance: "0.5km from center",
    rating: 4.6,
    reviews: 512,
    price: 850,
    image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&q=80&w=800",
    amenities: ["Ocean View", "Rooftop Terrace", "Restaurant"],
    type: "Hotel"
  },
  {
    id: 3,
    name: "Grand Plaza Royal",
    location: "Paris, France",
    distance: "0.2km from center",
    rating: 4.7,
    reviews: 890,
    price: 650,
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80",
    amenities: ["City View", "Michelin Dining", "Fitness Center"],
    type: "Hotel"
  },
  {
    id: 4,
    name: "Desert Oasis Resort",
    location: "Dubai, UAE",
    distance: "15km from center",
    rating: 4.9,
    reviews: 420,
    price: 850,
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80",
    amenities: ["Desert Tours", "Infinity Pool", "Helipad", "Spa & Wellness"],
    type: "Resort"
  },
  {
    id: 5,
    name: "Tuscan Sun Villa",
    location: "Florence, Italy",
    distance: "5km from center",
    rating: 4.5,
    reviews: 210,
    price: 450,
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80",
    amenities: ["Private Pool", "Vineyard View", "Free WiFi"],
    type: "Villa"
  },
  {
    id: 6,
    name: "Alpine Retreat Guesthouse",
    location: "Swiss Alps",
    distance: "1km from lifts",
    rating: 4.2,
    reviews: 180,
    price: 250,
    image: "https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&q=80&w=800",
    amenities: ["Ski Access", "Fireplace", "Free Breakfast", "Free WiFi"],
    type: "Guesthouse"
  }
];

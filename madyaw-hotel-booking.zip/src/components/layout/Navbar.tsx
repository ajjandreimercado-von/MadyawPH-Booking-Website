import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, User, Search, X, ChevronRight, Crown, Tag, ArrowUpCircle, Key, Palmtree, Map, Compass, Landmark, Coffee, HeartPulse } from 'lucide-react';
import { useState, useEffect } from 'react';
import AuthModal from '../auth/AuthModal';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../ui/ToastProvider';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; tab: 'guest' | 'partner' }>({
    isOpen: false,
    tab: 'guest'
  });
  const location = useLocation();
  const isHome = location.pathname === '/';
  const { user, logout } = useAuth();
  const { showToast } = useToast();

  const mockNavigate = (e: React.MouseEvent, target: string) => {
    e.preventDefault();
    showToast({ title: `Navigating to ${target}... (Mockup)`, type: 'info' });
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled || !isHome || mobileMenuOpen
            ? 'bg-brand-dark shadow-md py-5'
            : 'bg-transparent py-8'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <span className={`text-3xl font-serif font-bold tracking-tighter uppercase transition-colors ${
              scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory' : 'text-brand-ivory drop-shadow-md'
            }`}>
              Madyaw
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10">
            {/* Destinations */}
            <div className="relative group/dest py-4">
              <a
                href="#"
                onClick={(e) => mockNavigate(e, 'Destinations')}
                className={`text-[10px] font-bold tracking-widest uppercase transition-colors hover:opacity-100 ${
                  scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory opacity-80 hover:text-brand-primary' : 'text-brand-ivory drop-shadow-sm'
                }`}
              >
                Destinations
              </a>
              <div className="absolute top-[calc(100%+0px)] left-1/2 -translate-x-1/2 w-[850px] bg-brand-ivory text-brand-dark rounded-2xl shadow-luxury border border-brand-secondary/20 p-8 opacity-0 translate-y-4 pointer-events-none group-hover/dest:opacity-100 group-hover/dest:translate-y-0 group-hover/dest:pointer-events-auto transition-all duration-300 z-50 overflow-hidden cursor-default before:absolute before:-top-4 before:left-0 before:w-full before:h-4 before:bg-transparent">
                <div className="grid grid-cols-[1fr_2fr] gap-10">
                  {/* Left Column: Text list */}
                  <div>
                    <h3 className="font-serif font-bold text-2xl mb-5 text-brand-dark">Curated Escapes</h3>
                    <div className="space-y-6">
                      <div>
                        <h4 className="flex items-center gap-2 text-[10px] uppercase tracking-widest font-bold text-brand-primary mb-3">
                          <Palmtree className="w-4 h-4" /> Tropical
                        </h4>
                        <ul className="space-y-3 text-sm font-medium">
                          <li><a href="#" className="hover:text-brand-primary transition-colors block">Maldives Private Islands</a></li>
                          <li><a href="#" className="hover:text-brand-primary transition-colors block">Bali Wellness Retreats</a></li>
                          <li><a href="#" className="hover:text-brand-primary transition-colors block">Palawan Secret Shores</a></li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="flex items-center gap-2 text-[10px] uppercase tracking-widest font-bold text-brand-primary mb-3">
                          <Map className="w-4 h-4" /> Alpine & Urban
                        </h4>
                        <ul className="space-y-3 text-sm font-medium">
                          <li><a href="#" className="hover:text-brand-primary transition-colors block">Swiss Chalets</a></li>
                          <li><a href="#" className="hover:text-brand-primary transition-colors block">Tokyo Penthouses</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  {/* Right Column: Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { name: 'Palawan, PH', img: 'https://images.unsplash.com/photo-1518509562904-e7ef99cdcc86?auto=format&fit=crop&q=80&w=600' },
                      { name: 'Santorini, GR', img: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac542?auto=format&fit=crop&q=80&w=600' },
                      { name: 'Kyoto, JP', img: 'https://images.unsplash.com/photo-1493976040322-c1cb5054144e?auto=format&fit=crop&q=80&w=600' },
                      { name: 'Swiss Alps', img: 'https://images.unsplash.com/photo-1533250892015-4fa8892f25b2?auto=format&fit=crop&q=80&w=600' }
                    ].map((dest, i) => (
                      <div key={i} className="group/card relative rounded-xl overflow-hidden aspect-[4/3] cursor-pointer shadow-sm">
                         <img src={dest.img} alt={dest.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover/card:scale-110" />
                         <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/80 to-transparent" />
                         <span className="absolute bottom-4 left-4 text-brand-ivory font-bold text-sm tracking-wide">{dest.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Experiences */}
            <div className="relative group/exp py-4">
              <a
                href="#"
                onClick={(e) => mockNavigate(e, 'Experiences')}
                className={`text-[10px] font-bold tracking-widest uppercase transition-colors hover:opacity-100 ${
                  scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory opacity-80 hover:text-brand-primary' : 'text-brand-ivory drop-shadow-sm'
                }`}
              >
                Experiences
              </a>
              <div className="absolute top-[calc(100%+0px)] left-1/2 -translate-x-1/2 w-[700px] bg-brand-ivory text-brand-dark rounded-2xl shadow-luxury border border-brand-secondary/20 p-8 opacity-0 translate-y-4 pointer-events-none group-hover/exp:opacity-100 group-hover/exp:translate-y-0 group-hover/exp:pointer-events-auto transition-all duration-300 z-50 cursor-default before:absolute before:-top-4 before:w-full before:h-4 before:left-0 before:bg-transparent">
                <div className="flex flex-col gap-8">
                  {/* Top: Icons */}
                  <div className="grid grid-cols-4 gap-4">
                    {[
                      { icon: HeartPulse, label: 'Wellness & Spa' },
                      { icon: Coffee, label: 'Culinary Journeys' },
                      { icon: Compass, label: 'Adventure' },
                      { icon: Landmark, label: 'Culture' }
                    ].map((exp, i) => {
                      const Icon = exp.icon;
                      return (
                        <div key={i} className="flex flex-col items-center gap-3 p-4 rounded-xl hover:bg-brand-primary/5 transition-colors cursor-pointer group/icon">
                          <div className="w-14 h-14 rounded-full bg-brand-primary/10 text-brand-primary flex items-center justify-center group-hover/icon:bg-brand-primary group-hover/icon:text-brand-ivory transition-colors">
                            <Icon className="w-6 h-6" />
                          </div>
                          <span className="text-xs font-bold font-sans text-center">{exp.label}</span>
                        </div>
                      );
                    })}
                  </div>
                  {/* Bottom: Featured Experience */}
                  <div className="relative rounded-xl overflow-hidden h-56 group/feat cursor-pointer shadow-md">
                    <img src="https://images.unsplash.com/photo-1544333323-d3ac78216cd3?auto=format&fit=crop&q=80&w=1200" alt="Yacht" className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover/feat:scale-105" />
                    <div className="absolute inset-0 bg-brand-dark/40 group-hover/feat:bg-brand-dark/50 transition-colors" />
                    <div className="absolute inset-0 p-6 flex flex-col justify-end">
                      <span className="text-[10px] uppercase font-bold tracking-widest text-brand-primary mb-3 bg-brand-ivory px-3 py-1 rounded-full self-start shadow-sm">Featured</span>
                      <h4 className="text-2xl font-serif font-bold text-white mb-2">Private Yacht Sunset Cruise</h4>
                      <div className="flex items-center text-white/80 text-sm font-bold group-hover/feat:text-brand-ivory transition-colors opacity-0 translate-y-2 group-hover/feat:opacity-100 group-hover/feat:translate-y-0 duration-300">
                        <span>Explore Experience</span>
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* The Club */}
            <div className="relative group/club py-4">
              <a
                href="#"
                onClick={(e) => mockNavigate(e, 'The Club')}
                className={`text-[10px] font-bold tracking-widest uppercase transition-colors hover:opacity-100 ${
                  scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory opacity-80 hover:text-brand-primary' : 'text-brand-ivory drop-shadow-sm'
                }`}
              >
                The Club
              </a>
              <div className="absolute top-[calc(100%+0px)] right-0 w-[400px] bg-brand-ivory text-brand-dark rounded-2xl shadow-luxury border border-brand-secondary/20 p-8 opacity-0 translate-y-4 pointer-events-none group-hover/club:opacity-100 group-hover/club:translate-y-0 group-hover/club:pointer-events-auto transition-all duration-300 z-50 cursor-default before:absolute before:-top-4 before:w-full before:h-4 before:left-0 before:bg-transparent">
                <div className="flex flex-col gap-6">
                  {/* Status */}
                  <div className="bg-brand-primary/5 rounded-xl p-6 border border-brand-primary/10">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <p className="text-[10px] uppercase tracking-widest font-bold text-brand-primary/70 mb-1">Current Tier</p>
                        <p className="text-2xl font-serif font-bold text-brand-primary">Madyaw Base</p>
                      </div>
                      <Crown className="w-8 h-8 text-brand-primary opacity-30 mt-1" />
                    </div>
                    <div>
                      <div className="flex justify-between text-[11px] font-bold mb-2 uppercase tracking-wide">
                        <span className="text-brand-dark">4,500 pts</span>
                        <span className="text-brand-primary/70">10,000 pts to Elite</span>
                      </div>
                      <div className="w-full bg-brand-secondary/20 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-brand-primary h-full w-[45%] rounded-full" />
                      </div>
                    </div>
                  </div>
                  {/* Perks */}
                  <div className="px-1">
                    <h4 className="text-[10px] uppercase tracking-widest font-bold text-brand-dark/50 mb-4">Your Premium Benefits</h4>
                    <ul className="space-y-4">
                      <li className="flex items-center gap-4 text-sm font-bold text-brand-dark">
                        <div className="w-10 h-10 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary shrink-0">
                          <Tag className="w-4 h-4" />
                        </div>
                        Exclusive Member Rates
                      </li>
                      <li className="flex items-center gap-4 text-sm font-bold text-brand-dark">
                        <div className="w-10 h-10 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary shrink-0">
                          <ArrowUpCircle className="w-4 h-4" />
                        </div>
                        Priority Room Upgrades
                      </li>
                      <li className="flex items-center gap-4 text-sm font-bold text-brand-dark">
                        <div className="w-10 h-10 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary shrink-0">
                          <Key className="w-4 h-4" />
                        </div>
                        Private Concierge Access
                      </li>
                    </ul>
                  </div>
                  {/* CTA */}
                  <button className="w-full py-4 bg-brand-primary text-brand-ivory rounded-xl font-bold tracking-widest uppercase text-[10px] hover:bg-brand-dark transition-colors shadow-md mt-4">
                    View Club Dashboard
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <div className="relative group flex items-center gap-4">
                <div className="flex items-center gap-3 cursor-pointer py-2">
                  <span className={`text-[12px] font-bold tracking-widest uppercase ${scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory' : 'text-brand-ivory drop-shadow-sm'}`}>
                    {user.name}
                  </span>
                  <div className="w-9 h-9 rounded-full bg-brand-primary border-2 border-white/50 flex items-center justify-center text-white font-bold shadow-sm group-hover:scale-105 transition-transform">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                </div>
                
                {/* Dropdown menu */}
                <div className="absolute top-full right-0 mt-1 w-56 bg-white shadow-luxury rounded-2xl py-3 opacity-0 translate-y-2 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto transition-all duration-300 z-50 border border-brand-secondary/20">
                  <div className="px-4 pb-3 mb-2 border-b border-brand-secondary/20">
                    <p className="font-bold text-sm text-brand-dark">{user.name}</p>
                    <p className="text-xs text-brand-dark">{user.email}</p>
                  </div>
                  <button onClick={(e) => mockNavigate(e, 'My Bookings')} className="w-full text-left px-4 py-2.5 text-sm font-bold text-brand-dark hover:bg-brand-secondary/20 transition-colors flex items-center gap-2">
                    My Bookings
                  </button>
                  <button onClick={(e) => mockNavigate(e, 'Profile Settings')} className="w-full text-left px-4 py-2.5 text-sm font-bold text-brand-dark hover:bg-brand-secondary/20 transition-colors flex items-center gap-2">
                    Profile Settings
                  </button>
                  <div className="h-px bg-brand-secondary/20 my-2" />
                  <button onClick={logout} className="w-full text-left px-4 py-2.5 text-sm font-bold text-brand-primary hover:bg-brand-secondary/20 transition-colors">
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <>
                <button
                  onClick={() => setAuthModal({ isOpen: true, tab: 'guest' })}
                  className={`px-6 py-2 rounded-full text-[10px] font-bold tracking-widest uppercase transition-all duration-300 border active:scale-95 ${
                    scrolled || !isHome || mobileMenuOpen
                      ? 'border-brand-primary text-brand-primary hover:bg-brand-primary hover:text-brand-ivory'
                      : 'border-white text-white hover:bg-white/20 backdrop-blur-md'
                  }`}
                >
                  Guest Login
                </button>
                <button
                  onClick={() => setAuthModal({ isOpen: true, tab: 'partner' })}
                  className={`px-6 py-2 rounded-full text-[10px] font-bold tracking-widest uppercase transition-all duration-300 active:scale-95 ${
                    scrolled || !isHome || mobileMenuOpen
                      ? 'bg-brand-primary text-brand-ivory hover:bg-brand-dark border border-brand-primary'
                      : 'bg-white text-brand-dark hover:bg-brand-ivory border border-white'
                  }`}
                >
                  Partner Portal
                </button>
              </>
            )}
          </div>

          {/* Mobile Toggle */}
          <button
            className="md:hidden p-2 text-current"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className={`w-6 h-6 ${scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory' : 'text-brand-ivory'}`} />
            ) : (
              <Menu className={`w-6 h-6 ${scrolled || !isHome || mobileMenuOpen ? 'text-brand-ivory' : 'text-brand-ivory'}`} />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-brand-secondary/20 bg-brand-ivory absolute top-full left-0 right-0 shadow-lg overflow-hidden"
            >
              <div className="px-4 py-6 flex flex-col gap-4">
                {['Destinations', 'Experiences', 'The Club'].map((item) => (
                  <a
                    key={item}
                    href="#"
                    className="text-lg font-serif text-brand-dark hover:text-brand-primary font-bold"
                    onClick={(e) => {
                      setMobileMenuOpen(false);
                      mockNavigate(e, item);
                    }}
                  >
                    {item}
                  </a>
                ))}
                <div className="h-px bg-brand-secondary/20 w-full my-2" />
                {user ? (
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-3 px-2 py-3 bg-brand-cream/50 rounded-xl mb-2">
                      <div className="w-10 h-10 rounded-full bg-brand-primary flex items-center justify-center text-white font-bold text-lg">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-sm text-brand-dark">{user.name}</p>
                        <p className="text-xs text-brand-dark/60">{user.email}</p>
                      </div>
                    </div>
                    <button onClick={(e) => { setMobileMenuOpen(false); mockNavigate(e, 'My Bookings'); }} className="text-left font-bold text-sm text-brand-dark py-2 px-2 hover:text-brand-primary">My Bookings</button>
                    <button onClick={(e) => { setMobileMenuOpen(false); mockNavigate(e, 'Profile Settings'); }} className="text-left font-bold text-sm text-brand-dark py-2 px-2 hover:text-brand-primary">Profile Settings</button>
                    <button onClick={() => { setMobileMenuOpen(false); logout(); }} className="text-left font-bold text-sm text-red-600 py-2 px-2 mt-2 border-t border-brand-secondary/20">Logout</button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setAuthModal({ isOpen: true, tab: 'guest' });
                    }}
                    className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-brand-primary text-brand-ivory font-medium hover:bg-brand-dark transition-colors active:scale-95"
                  >
                    <User className="w-5 h-5" />
                    <span>Sign In / Partner Portal</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <AuthModal 
        isOpen={authModal.isOpen} 
        onClose={() => setAuthModal(prev => ({ ...prev, isOpen: false }))}
        initialTab={authModal.tab}
      />
    </>
  );
}

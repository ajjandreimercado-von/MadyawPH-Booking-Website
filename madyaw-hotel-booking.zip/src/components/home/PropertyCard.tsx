import { motion } from 'motion/react';
import { Star, MapPin, Heart } from 'lucide-react';
import { Property } from '../../types';
import { useState } from 'react';
import { useToast } from '../ui/ToastProvider';

interface PropertyCardProps {
  property: Property;
  index: number;
  onViewDetails: (property: Property) => void;
}

export default function PropertyCard({ property, index, onViewDetails }: PropertyCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  const { toast } = useToast();

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
    if (!isFavorite) {
      toast('Added to Favorites');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl border border-brand-secondary/30 group transition-all duration-300 flex flex-col"
    >
      <div className="h-52 bg-brand-dark relative overflow-hidden">
        <img 
          src={property.image} 
          alt={property.name}
          className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-700 ease-out"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur border border-brand-secondary/50 px-3 py-1 rounded-full text-[11px] font-sans font-bold text-brand-dark shadow-sm">
          {property.rating} Superb
        </div>
        <button 
          onClick={handleFavorite}
          className="absolute top-4 left-4 p-2 bg-white/60 backdrop-blur-sm rounded-full active:scale-95 transition-transform hover:bg-white"
        >
          <Heart className={`w-5 h-5 transition-colors ${isFavorite ? 'fill-brand-primary text-brand-primary' : 'text-brand-dark'}`} />
        </button>
      </div>
      
      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start gap-4">
          <h4 className="font-serif text-2xl font-bold text-brand-dark">
            {property.name}
          </h4>
          <div className="text-right">
            <p className="text-xl font-serif font-bold text-brand-primary">
              ${property.price}
              <span className="text-xs font-sans font-normal block text-brand-dark">per night</span>
            </p>
          </div>
        </div>

        <p className="text-xs mt-2 uppercase tracking-wider text-brand-dark font-bold line-clamp-1">
          {property.location} • {property.amenities.slice(0, 2).join(' • ')}
        </p>

        <div className="h-px bg-brand-secondary/30 my-4" />

        <div className="flex justify-between items-center mt-auto">
          <div className="flex items-center gap-1.5 font-bold text-brand-dark text-sm">
            <Star className="w-4 h-4 fill-brand-primary text-brand-primary" />
            <span>{property.rating.toFixed(1)}</span>
          </div>
          <button 
            onClick={() => onViewDetails(property)}
            className="px-5 py-2 bg-brand-primary text-brand-ivory text-[10px] font-bold uppercase tracking-widest rounded-lg hover:bg-brand-dark transition-all duration-300 active:scale-95 shadow-sm"
          >
            View Details
          </button>
        </div>
      </div>
    </motion.div>
  );
}

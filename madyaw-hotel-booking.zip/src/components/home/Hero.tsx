import { motion } from 'motion/react';
import { MapPin, Calendar, Users, Search as SearchIcon } from 'lucide-react';
import { useState } from 'react';

export default function Hero() {
  const [guests, setGuests] = useState(2);
  const [rooms, setRooms] = useState(1);

  return (
    <div className="relative h-[80vh] min-h-[600px] flex items-center justify-center pt-20">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url('/hero-bg.jpg')` }}
      >
        <div className="absolute inset-0 bg-brand-dark/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-5xl mx-auto px-4 sm:px-6 flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-center mb-10"
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white mb-4 drop-shadow-lg">
            Find Your Sanctuary
          </h1>
          <p className="text-lg md:text-xl text-white/90 font-sans font-light max-w-2xl mx-auto drop-shadow">
            Experience luxury woven into every detail. Discover hand-picked resorts, villas, and hotels worldwide.
          </p>
        </motion.div>

        {/* Search Bar Container */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="w-full bg-brand-cream/95 backdrop-blur-xl rounded-2xl shadow-luxury border border-brand-secondary/20 p-5"
        >
          <div className="flex flex-col xl:flex-row items-start xl:items-end gap-6 relative">
            
            {/* Location Input */}
            <div className="flex-1 w-full relative group">
              <label className="block text-[10px] uppercase font-bold tracking-widest mb-2 opacity-60 text-brand-dark">Destination</label>
              <div className="border-b border-brand-secondary pb-1 flex items-center gap-2 group-focus-within:border-brand-primary transition-colors">
                <MapPin className="w-4 h-4 text-brand-secondary" />
                <input 
                  type="text" 
                  placeholder="Where are you going?" 
                  className="bg-transparent border-none outline-none text-brand-dark placeholder-brand-dark/40 text-lg font-serif italic w-full"
                />
              </div>
            </div>

            {/* Dates Input */}
            <div className="flex-1 xl:w-48 relative group cursor-pointer w-full">
              <label className="block text-[10px] uppercase font-bold tracking-widest mb-2 opacity-60 text-brand-dark">Check-in / Out</label>
              <div className="border-b border-brand-secondary pb-1 flex items-center gap-2 group-hover:border-brand-primary transition-colors">
                <Calendar className="w-4 h-4 text-brand-secondary" />
                <div className="text-lg font-serif italic text-brand-dark">
                  Add dates
                </div>
              </div>
            </div>

            {/* Guests Input */}
            <div 
              className="flex-1 xl:w-48 relative group cursor-pointer w-full"
              onClick={() => {
                setGuests(prev => prev >= 4 ? 1 : prev + 1);
                setRooms(prev => prev >= 2 ? 1 : prev + (guests === 3 ? 1 : 0));
              }}
              title="Click to cycle guest count"
            >
              <label className="block text-[10px] uppercase font-bold tracking-widest mb-2 opacity-60 text-brand-dark">Guests</label>
              <div className="border-b border-brand-secondary pb-1 flex items-center gap-2 group-hover:border-brand-primary transition-colors">
                <Users className="w-4 h-4 text-brand-secondary" />
                <div className="text-lg font-serif italic text-brand-dark">
                  {guests} Guest{guests !== 1 ? 's' : ''}, {rooms} Room{rooms !== 1 ? 's' : ''}
                </div>
              </div>
            </div>

            {/* Search Button */}
            <button className="w-full xl:w-auto px-10 py-4 bg-brand-primary text-brand-ivory rounded-xl font-bold tracking-widest uppercase text-xs flex items-center justify-center gap-2 hover:bg-brand-dark transition-colors duration-300 active:scale-95 shadow-md">
              <SearchIcon className="w-4 h-4" />
              <span>Find Sanctuary</span>
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

import { FilterState } from '../../types';
import * as Slider from '@radix-ui/react-slider';
import { Check } from 'lucide-react';

interface FilterSidebarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  totalResults: number;
}

const PROPERTY_TYPES = ['Hotel', 'Resort', 'Villa', 'Apartment', 'Guesthouse'];
const AMENITIES = ['Pool', 'Free WiFi', 'Spa & Wellness', 'Fitness Center', 'Private Beach', 'Michelin Dining'];

export default function FilterSidebar({ filters, setFilters, totalResults }: FilterSidebarProps) {
  
  const handleTypeToggle = (type: string) => {
    setFilters(prev => ({
      ...prev,
      types: prev.types.includes(type) 
        ? prev.types.filter(t => t !== type)
        : [...prev.types, type]
    }));
  };

  const handleStarToggle = (stars: number) => {
    setFilters(prev => ({
      ...prev,
      rating: prev.rating === stars ? 0 : stars // Toggle or set
    }));
  };

  const handleAmenityToggle = (amenity: string) => {
    setFilters(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  return (
    <div className="w-full lg:w-64 flex-shrink-0 bg-brand-secondary/10 p-6 rounded-3xl border border-brand-secondary/30 flex flex-col h-full overflow-hidden space-y-6">
      {/* Search Header */}
      <div>
        <h3 className="font-serif italic text-xl mb-2 text-brand-dark">Refine Search</h3>
        <p className="text-xs text-brand-dark font-bold">Showing {totalResults} properties</p>
      </div>

      <div className="h-px bg-brand-secondary/30" />

      {/* Price Range */}
      <div className="space-y-3">
        <p className="text-[10px] uppercase font-bold tracking-widest mb-3 text-brand-dark">Price Nightly</p>
        <div className="pt-2 px-1">
          <Slider.Root
            className="relative flex items-center select-none touch-none w-full h-5 cursor-pointer"
            defaultValue={[0, 2000]}
            max={2000}
            step={50}
            min={0}
            value={filters.priceRange}
            onValueChange={(val) => setFilters(prev => ({ ...prev, priceRange: val }))}
          >
            <Slider.Track className="bg-brand-secondary/30 relative grow rounded-full h-1">
              <Slider.Range className="absolute bg-brand-primary rounded-full h-full" />
            </Slider.Track>
            <Slider.Thumb className="block w-3 h-3 bg-brand-primary shadow-sm rounded-full hover:scale-110 focus:outline-none focus:ring-2 focus:ring-brand-primary/40 transition-transform" />
            <Slider.Thumb className="block w-3 h-3 bg-brand-primary shadow-sm rounded-full hover:scale-110 focus:outline-none focus:ring-2 focus:ring-brand-primary/40 transition-transform" />
          </Slider.Root>
          <div className="flex justify-between items-center mt-3 text-[10px] font-bold text-brand-dark">
            <span>${filters.priceRange[0]}</span>
            <span>${filters.priceRange[1]}</span>
          </div>
        </div>
      </div>

      <div className="h-px bg-brand-secondary/30" />

      {/* Property Type */}
      <div className="space-y-3">
        <p className="text-[10px] uppercase font-bold tracking-widest mb-3 text-brand-dark">Property Type</p>
        <div className="space-y-2">
          {PROPERTY_TYPES.map((type) => (
            <label key={type} className={`flex items-center gap-3 cursor-pointer group text-xs transition-colors font-bold ${filters.types.includes(type) ? 'text-brand-primary' : 'text-brand-dark hover:text-brand-primary'}`}>
              <div className={`relative flex items-center justify-center w-4 h-4 rounded-[3px] border transition-colors ${filters.types.includes(type) ? 'border-brand-primary bg-brand-primary' : 'border-brand-dark/40 bg-white group-hover:border-brand-primary'}`}>
                <input 
                  type="checkbox" 
                  className="sr-only" 
                  checked={filters.types.includes(type)}
                  onChange={() => handleTypeToggle(type)}
                />
                {filters.types.includes(type) && <Check className="w-3 h-3 text-white z-10" />}
              </div>
              <span>{type}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="h-px bg-brand-secondary/30" />

      {/* Star Rating */}
      <div className="space-y-3">
        <p className="text-[10px] uppercase font-bold tracking-widest mb-3 text-brand-dark">Star Rating</p>
        <div className="space-y-2">
          {[5, 4, 3].map((stars) => {
            const isChecked = filters.rating === stars;
            return (
              <label key={stars} className={`flex items-center gap-3 cursor-pointer group text-xs transition-colors font-bold ${isChecked ? 'text-brand-primary' : 'text-brand-dark hover:text-brand-primary'}`}>
                <div className={`relative flex items-center justify-center w-4 h-4 rounded-[3px] border transition-colors ${isChecked ? 'border-brand-primary bg-brand-primary' : 'border-brand-dark/40 bg-white group-hover:border-brand-primary'}`}>
                  <input 
                    type="checkbox" 
                    className="sr-only" 
                    checked={isChecked}
                    onChange={() => handleStarToggle(stars)}
                  />
                  {isChecked && <Check className="w-3 h-3 text-white z-10" />}
                </div>
                <span className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className={`w-3 h-3 rounded-full ${i < stars ? 'bg-brand-primary' : 'bg-brand-secondary/30'}`} />
                  ))}
                </span>
              </label>
            );
          })}
        </div>
      </div>

      <div className="h-px bg-brand-secondary/30" />

      {/* Amenities */}
      <div className="space-y-3">
        <p className="text-[10px] uppercase font-bold tracking-widest mb-3 text-brand-dark">Amenities</p>
        <div className="space-y-2">
          {AMENITIES.map((amenity) => {
             const isChecked = filters.amenities.includes(amenity);
             return (
              <label key={amenity} className={`flex items-center gap-3 cursor-pointer group text-xs transition-colors font-bold ${isChecked ? 'text-brand-primary' : 'text-brand-dark hover:text-brand-primary'}`}>
                <div className={`relative flex items-center justify-center w-4 h-4 rounded-[3px] border transition-colors ${isChecked ? 'border-brand-primary bg-brand-primary' : 'border-brand-dark/40 bg-white group-hover:border-brand-primary'}`}>
                  <input 
                    type="checkbox" 
                    className="sr-only" 
                    checked={isChecked}
                    onChange={() => handleAmenityToggle(amenity)}
                  />
                  {isChecked && <Check className="w-3 h-3 text-white z-10" />}
                </div>
                <span>{amenity}</span>
              </label>
             )
          })}
        </div>
      </div>
    </div>
  );
}

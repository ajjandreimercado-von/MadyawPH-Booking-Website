import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, Building, ArrowRight, User, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../ui/ToastProvider';

type AuthTab = 'guest' | 'partner';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: AuthTab;
  onSuccess?: () => void;
}

export default function AuthModal({ isOpen, onClose, initialTab = 'guest', onSuccess }: AuthModalProps) {
  const [activeTab, setActiveTab] = useState<AuthTab>(initialTab);
  const { login } = useAuth();
  const { showToast } = useToast();
  
  const [guestEmail, setGuestEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const handleGuestLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      login(guestEmail || 'guest@example.com');
      showToast({ title: 'Successfully logged in!', description: 'Welcome to Madyaw.', type: 'success' });
      setIsLoading(false);
      onClose();
      onSuccess?.();
    }, 1000);
  };

  const handlePartnerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      showToast({ title: 'Partner Login', description: 'This feature is a mock demo.', type: 'info' });
    }, 1000);
  };

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
        {/* Backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-brand-dark/40 backdrop-blur-sm"
        />

        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-[480px] bg-white rounded-[2rem] shadow-2xl overflow-y-auto max-h-[90vh] relative z-10 border border-brand-secondary/10"
        >
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 bg-brand-dark/5 hover:bg-brand-dark/10 rounded-full transition-colors active:scale-95 text-brand-dark hover:text-brand-primary"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
          </button>

          <div className="p-8 md:p-10 relative">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-serif font-bold text-brand-dark mb-3">Welcome Back</h2>
              <p className="text-brand-dark font-sans font-bold text-sm">Please sign in to continue your journey.</p>
            </div>

            {/* Tabs */}
            <div className="flex p-1.5 bg-brand-secondary/10 rounded-2xl mb-8 relative border border-brand-secondary/20">
              {['guest', 'partner'].map((tab) => {
                const isActive = activeTab === tab;
                return (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab as AuthTab)}
                    className={`flex-1 flex justify-center items-center gap-2 py-3 text-xs font-bold uppercase tracking-widest rounded-xl transition-colors duration-300 relative z-10 ${
                      isActive ? 'text-brand-dark bg-white shadow-sm' : 'text-brand-dark hover:bg-white/50'
                    }`}
                  >
                    {tab === 'guest' ? <User className="w-4 h-4" /> : <Building className="w-4 h-4" />}
                    <span>{tab === 'guest' ? 'Traveler' : 'Partner Portal'}</span>
                  </button>
                );
              })}
            </div>

            {/* Forms container with AnimatePresence */}
            <div className="relative">
              <AnimatePresence mode="wait">
                {activeTab === 'guest' && (
                  <motion.form
                    key="guest"
                    onSubmit={handleGuestLogin}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-5"
                  >
                    <InputField 
                      icon={<Mail className="w-5 h-5" />} 
                      label="Email Address" 
                      type="email" 
                      placeholder="you@example.com"
                      value={guestEmail}
                      onChange={(e) => setGuestEmail(e.target.value)}
                    />
                    <InputField icon={<Lock className="w-5 h-5" />} label="Password" type="password" placeholder="••••••••" />
                    
                    <div className="flex justify-between items-center py-2">
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <div className="relative flex items-center justify-center w-4 h-4 rounded-[3px] border border-brand-secondary bg-brand-cream group-hover:border-brand-primary transition-colors">
                          <input type="checkbox" className="peer sr-only" />
                          <div className="w-2.5 h-2.5 rounded-sm bg-brand-primary scale-0 peer-checked:scale-100 transition-transform origin-center" />
                        </div>
                        <span className="text-xs font-bold text-brand-dark/70">Remember me</span>
                      </label>
                      <Link to="#" className="text-xs font-bold hover:text-brand-primary transition-colors text-brand-dark">
                        Forgot Password?
                      </Link>
                    </div>

                    <button 
                      type="submit"
                      className="w-full py-4 bg-brand-primary text-brand-ivory rounded-xl text-xs tracking-widest uppercase font-bold flex justify-center items-center gap-2 hover:bg-brand-dark transition-colors duration-300 mt-6 shadow-md shadow-brand-primary/20 active:scale-95 focus:ring-4 focus:ring-brand-primary/20 outline-none"
                    >
                      <span>Sign In to Book</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <div className="text-center pt-4">
                      <span className="text-xs font-bold text-brand-dark">New to Madyaw? </span>
                      <Link to="#" className="text-xs font-bold text-brand-primary hover:underline">
                        Create an account
                      </Link>
                    </div>
                  </motion.form>
                )}

                {activeTab === 'partner' && (
                  <motion.form
                    key="partner"
                    onSubmit={handlePartnerLogin}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-5"
                  >
                    <InputField icon={<Building className="w-5 h-5" />} label="Property ID / Email" type="text" placeholder="PID-12345" />
                    <InputField icon={<Lock className="w-5 h-5" />} label="Portal Password" type="password" placeholder="••••••••" />
                    
                    <button type="submit" disabled={isLoading} className="w-full py-4 bg-brand-dark text-brand-ivory border border-transparent rounded-xl text-xs uppercase tracking-widest font-bold flex justify-center items-center gap-2 hover:bg-brand-primary transition-colors duration-300 mt-8 shadow-md active:scale-95 focus:ring-4 focus:ring-brand-dark/20 outline-none disabled:opacity-70">
                      {isLoading ? (
                        <div className="w-5 h-5 border-2 border-brand-ivory/30 border-t-brand-ivory rounded-full animate-spin" />
                      ) : (
                        <>
                          <span>Access Dashboard</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>

                    <div className="text-center pt-4">
                      <span className="text-xs font-bold text-brand-dark">Want to list your property? </span>
                      <Link to="#" className="text-xs font-bold text-brand-primary hover:underline">
                        Apply as Partner
                      </Link>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>

            {/* Social Logins - Only for Guests */}
            <AnimatePresence>
              {activeTab === 'guest' && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="pt-8 mt-8 border-t border-brand-secondary/20"
                >
                  <div className="text-center mb-6 relative">
                    <span className="absolute inset-0 top-1/2 -translate-y-1/2 flex items-center" aria-hidden="true">
                      <div className="w-full border-t border-brand-secondary/30" />
                    </span>
                    <div className="relative flex justify-center">
                      <span className="bg-brand-cream px-4 text-[10px] tracking-widest font-bold text-brand-dark uppercase">Or continue with</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <button className="flex justify-center items-center gap-3 py-3 px-4 rounded-xl border border-brand-secondary/30 hover:bg-brand-ivory transition-colors active:scale-95">
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                      </svg>
                      <span className="text-xs font-bold text-brand-dark">Google</span>
                    </button>
                    <button className="flex justify-center items-center gap-3 py-3 px-4 rounded-xl border border-brand-secondary/30 hover:bg-brand-ivory transition-colors active:scale-95">
                      <svg className="w-4 h-4 text-brand-dark" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.04 2.26-.86 3.77-.73 1.57.14 2.76.71 3.5 1.76-3.1 1.83-2.58 5.86.37 7.02-.75 1.64-1.6 3.25-2.72 4.12zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
                      </svg>
                      <span className="text-xs font-bold text-brand-dark">Apple</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

// Reusable Input Component
function InputField({ icon, label, type, placeholder, value, onChange }: { icon: React.ReactNode, label: string, type: string, placeholder: string, value?: string, onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void }) {
  return (
    <div className="relative group">
      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-secondary group-focus-within:text-brand-primary transition-colors">
        {icon}
      </div>
      <div className="h-full flex flex-col justify-center px-12 py-3 bg-brand-secondary/5 rounded-xl hover:bg-brand-secondary/10 focus-within:bg-white transition-all cursor-text border border-brand-secondary/30 focus-within:border-brand-primary shadow-sm">
        <label className="text-[10px] font-bold text-brand-dark uppercase tracking-widest mb-0.5">{label}</label>
        <input 
          type={type} 
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          className="bg-transparent border-none outline-none text-brand-dark placeholder-brand-dark/50 text-sm font-bold w-full"
        />
      </div>
    </div>
  );
}

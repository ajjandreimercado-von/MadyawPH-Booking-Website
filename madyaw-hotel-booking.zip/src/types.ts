export interface Property {
  id: number;
  name: string;
  location: string;
  distance: string;
  rating: number;
  reviews: number;
  price: number;
  image: string;
  amenities: string[];
  type: string;
}

export interface FilterState {
  priceRange: number[];
  types: string[];
  rating: number;
  amenities: string[];
}
